import java.io.IOException;
import  java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;

public class Server {
    private DatagramSocket socket;
    private ArrayList<Client> queue;
    private byte[] buff;

    private InetAddress address;
    private int port;
    private String data;
    private DatagramPacket packet;

    public Server(int port) throws SocketException {
        socket = new DatagramSocket(port);
        queue = new ArrayList<>();
        buff = new byte[512];
    }

    class Client{
        private InetAddress address;
        private String name;
        private int port;
        Client(InetAddress address, int port, String name){
            this.address = address;
            this.port = port;
            this.name = name;
        }
    }

    private void getPacketInfo() throws IOException{
        packet = new DatagramPacket(buff, buff.length);
        socket.receive(packet);
        address = packet.getAddress();
        port = packet.getPort();
        data = new String(packet.getData(), 0, packet.getLength());
        //System.out.println(address+" "+port);
    }

    private void sendPacketInfo(String msg) throws IOException{
        buff = msg.getBytes();
        packet = new DatagramPacket(buff, buff.length, address, port);
        socket.send(packet);
    }

    private void processNewClient() throws IOException{
        //New client
        Client cur_client = new Client(address, port, data);
        queue.add(cur_client);
        int pos = queue.size();
        String msg = String.format("Welcome to the office hour, %s.\nYour current position is %d, please wait...\n", data, pos);
        sendPacketInfo(msg);
    }

    private void processHeadClient() throws IOException{
        if(!queue.isEmpty()) {
            Client head = queue.get(0);
            port = head.port;
            address = head.address;
            data = head.name;
            String msg = String.format("It's your turn now %s! Please proceed...\n", data);
            sendPacketInfo(msg);

            //Wait for the head client's response and remove
            while (true) {
                getPacketInfo();
                if (data.equals("Completed")) {
                    queue.remove(0);
                    processHeadClient();
                    break;
                } else {
                    processNewClient();
                }
            }
        }
    }

    public int run() throws IOException{
        while(true) {
            getPacketInfo();
            processNewClient();
            while (!queue.isEmpty()) {
                processHeadClient();
            }
        }
    }



}
