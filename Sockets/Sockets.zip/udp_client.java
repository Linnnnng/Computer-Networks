import java.io.IOException;
import  java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class udp_client {
    public static void main(String[] args) {
        try {
            //Initialization
            InetAddress address = InetAddress.getByName(args[0]);
            int port = Integer.parseInt(args[1]);
            String name = args[2];
            byte[] buff = name.getBytes();

            //Establish connection
            DatagramSocket socket = new DatagramSocket();
            DatagramPacket packet = new DatagramPacket(buff, buff.length, address, port);
            socket.send(packet);
            buff = new byte[512];
            packet = new DatagramPacket(buff, buff.length);
            socket.receive(packet);
            String server_msg = new String(packet.getData(), 0, packet.getLength());
            System.out.println(server_msg);

            //Waiting for serving
            socket.receive(packet);
            server_msg = new String(packet.getData(), 0, packet.getLength());
            System.out.println(server_msg);

            //Proceed and disconnect
            System.in.read();
            buff = "Completed".getBytes();
            packet = new DatagramPacket(buff, buff.length, address, port);
            socket.send(packet);
            socket.close();

        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
