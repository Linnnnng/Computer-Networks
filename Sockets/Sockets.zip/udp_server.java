import java.io.IOException;

public class udp_server {

    public static void main(String[] args) throws IOException {
        Server newServer = new Server(Integer.parseInt(args[0]));
        newServer.run();
    }
}
