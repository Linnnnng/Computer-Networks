import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class mystery_socket_receiver {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(21212);
        Socket clientSocket = serverSocket.accept();
        while(true) {
            BufferedReader bf = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            String msg = bf.readLine();
            Pattern pattern = Pattern.compile("PASSWORD=(.*?)\\.");
            Matcher matcher = pattern.matcher(msg);
            if(matcher.find()){
                System.out.println(matcher.group(1));
            }
        }
    }
}
